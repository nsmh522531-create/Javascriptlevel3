const taskInput = document.getElementById('taskInput');
const noteInput = document.getElementById('noteInput');
const addBtn = document.getElementById('addBtn');
const taskList = document.getElementById('taskList');
const taskCountElement = document.getElementById('taskCount');

let taskCount = 0;

function updateCounter() {
    taskCountElement.textContent = taskCount;
}

addBtn.addEventListener('click', function() {
    const taskValue = taskInput.value.trim();
    const noteValue = noteInput.value.trim();

    if (taskValue === '') {
        return;
    }

    const li = document.createElement('li');
    li.className = 'task-item';

    const textContainer = document.createElement('div');
    textContainer.className = 'task-text';

    const titleSpan = document.createElement('span');
    titleSpan.className = 'task-title';
    titleSpan.textContent = taskValue;
    textContainer.appendChild(titleSpan);

    if (noteValue !== '') {
        const noteSpan = document.createElement('span');
        noteSpan.className = 'task-note';
        noteSpan.textContent = `Note: ${noteValue}`;
        textContainer.appendChild(noteSpan);
    }

    li.appendChild(textContainer);

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'delete-btn';
    deleteBtn.textContent = 'Delete';
    
    deleteBtn.addEventListener('click', function() {
        taskList.removeChild(li);
        taskCount--;
        updateCounter();
    });

    li.appendChild(deleteBtn);

    taskList.appendChild(li);
    taskCount++;
    updateCounter();

    taskInput.value = '';
    noteInput.value = '';
});
